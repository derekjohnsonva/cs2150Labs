// Derek Johnson dej3tc@virginia.edu
// 9/7/19
//ListNode.cpp
#include <iostream>
#include "ListNode.h"
using namespace std;

// Constructor
ListNode::ListNode(void) {
}

